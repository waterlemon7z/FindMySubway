package com.example.find_my_subway

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
