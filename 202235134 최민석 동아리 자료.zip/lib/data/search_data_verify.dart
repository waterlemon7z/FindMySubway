bool verifySearchData(String data, List<String> addList)
{
    if(!addList.contains(data))
    {
      return true;
    }
  return false;

}